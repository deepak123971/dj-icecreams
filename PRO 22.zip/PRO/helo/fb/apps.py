from django.apps import AppConfig


class FbConfig(AppConfig):
    name = 'fb'
