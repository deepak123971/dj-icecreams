from django.contrib import admin
from fb.models import Contact

# Register your models here.
admin.site.register(Contact)